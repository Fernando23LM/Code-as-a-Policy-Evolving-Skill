"""Success check for the tube-rack task. Keep this file out of the agent's view."""
from __future__ import annotations

import numpy as np

from .scene import ARMS, RACK_BASE

XY_TOL = 0.006          # tube axis within 6 mm of the cell centre
SEAT_TOL = 0.006        # tube bottom within 6 mm of the rack base
TILT_TOL_DEG = 10.0
SPEED_TOL = 0.01        # m/s


def _in_cell(env, tube: str, rack, cell) -> bool:
    body = env.data.body(tube)
    xy_ok = np.linalg.norm(body.xpos[:2] - rack.cell_xy(*cell)) < XY_TOL
    return bool(xy_ok and abs(body.xpos[2] - RACK_BASE) < SEAT_TOL)


def evaluate(env) -> dict:
    m, d, task = env.model, env.data, env.task
    body = d.body(task.tube)
    tilt = float(np.degrees(np.arccos(np.clip(body.xmat.reshape(3, 3)[2, 2], -1, 1))))
    speed = float(np.linalg.norm(body.cvel[3:]))

    tube_id = m.body(task.tube).id
    robot_bodies = {b for b in range(m.nbody) if m.body(b).name.split("/")[0] in ARMS}
    held = any(
        {m.geom_bodyid[c.geom1], m.geom_bodyid[c.geom2]} & {tube_id}
        and {m.geom_bodyid[c.geom1], m.geom_bodyid[c.geom2]} & robot_bodies
        for c in d.contact[: d.ncon]
    )
    others_ok = all(
        _in_cell(env, name, env.layout.source, cell) for name, cell in env.layout.tubes.items() if name != task.tube
    )
    checks = {
        "in_target_cell": _in_cell(env, task.tube, env.layout.dest, task.dest_cell),
        "upright": tilt < TILT_TOL_DEG,
        "at_rest": speed < SPEED_TOL,
        "released": not held,
        "others_undisturbed": others_ok,
    }
    return {"success": all(checks.values()), "checks": checks, "tilt_deg": tilt}
