"""Bench scene: two I2RT YAM arms, a source tube rack and a destination rack.

Conventions (same as Documents/BiomedicalBenchmarks): metres, Z up, table top
is the plane z = 0, arms at (-0.20, +/-0.28, 0) facing +X.

The YAM can only point its gripper straight down within about 0.10-0.35 m of
its base and below z = 0.16 (wrist pitch limit), so both racks sit inside that
envelope of the right arm and the vials are short enough to carry over each other.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

import mujoco
import numpy as np

YAM_XML = Path(__file__).resolve().parents[1] / "third_party/mujoco_menagerie/i2rt_yam/yam.xml"

ARMS = ("left", "right")
ARM_BASE = {"left": (-0.20, 0.28, 0.0), "right": (-0.20, -0.28, 0.0)}
ARM_JOINTS = tuple(f"joint{i}" for i in range(1, 7))
HOME_Q = (0.0, 1.047, 1.047, 0.0, 0.0, 0.0)
GRIPPER_OPEN = 0.041  # finger actuator ctrl, metres of travel per finger

TUBE_RADIUS = 0.014
TUBE_LENGTH = 0.075
TUBE_MASS = 0.03

RACK_HOLE = 0.032    # square opening, 2 mm clearance each side of a tube
RACK_WALL = 0.005
RACK_PITCH = RACK_HOLE + RACK_WALL
RACK_HEIGHT = 0.035
RACK_BASE = 0.006

TUBE_COLORS = ((0.85, 0.2, 0.2, 1), (0.2, 0.45, 0.85, 1), (0.95, 0.75, 0.1, 1), (0.25, 0.7, 0.35, 1))


@dataclass
class Rack:
    name: str
    xy: tuple[float, float]
    nx: int = 4
    ny: int = 2
    yaw: float = 0.0

    def cell_xy(self, ix: int, iy: int) -> np.ndarray:
        """World xy of the centre of cell (ix, iy)."""
        local = np.array([(ix - (self.nx - 1) / 2) * RACK_PITCH, (iy - (self.ny - 1) / 2) * RACK_PITCH])
        c, s = np.cos(self.yaw), np.sin(self.yaw)
        return np.array(self.xy) + np.array([c * local[0] - s * local[1], s * local[0] + c * local[1]])

    def cells(self) -> list[tuple[int, int]]:
        return [(ix, iy) for iy in range(self.ny) for ix in range(self.nx)]


@dataclass
class Layout:
    """Everything that varies between episodes."""
    source: Rack = field(default_factory=lambda: Rack("rack_source", (0.02, -0.37)))
    dest: Rack = field(default_factory=lambda: Rack("rack_dest", (0.02, -0.19)))
    # tube name -> cell of the source rack it starts in
    tubes: dict[str, tuple[int, int]] = field(
        default_factory=lambda: {"tube_0": (0, 0), "tube_1": (3, 1)})

    @staticmethod
    def sample(rng: np.random.Generator, n_tubes: int = 2) -> "Layout":
        def jitter(xy, yaw_max=0.35):
            return (xy[0] + rng.uniform(-0.02, 0.02), xy[1] + rng.uniform(-0.02, 0.02)), rng.uniform(-yaw_max, yaw_max)

        (sxy, syaw), (dxy, dyaw) = jitter((0.02, -0.37)), jitter((0.02, -0.19))
        source, dest = Rack("rack_source", sxy, yaw=syaw), Rack("rack_dest", dxy, yaw=dyaw)
        # No two tubes in touching cells, diagonals included: the fingers need a free cell on each
        # side and the finger struts reach over the diagonal cells.
        cells = source.cells()
        while True:
            picks = [cells[int(j)] for j in rng.choice(len(cells), size=n_tubes, replace=False)]
            if all(max(abs(a[0] - b[0]), abs(a[1] - b[1])) > 1 for i, a in enumerate(picks) for b in picks[:i]):
                return Layout(source, dest, {f"tube_{i}": c for i, c in enumerate(picks)})


def _add_rack(spec: mujoco.MjSpec, rack: Rack, rgba) -> None:
    body = spec.worldbody.add_body(name=rack.name, pos=[*rack.xy, 0], quat=_yaw_quat(rack.yaw))
    lx, ly = rack.nx * RACK_PITCH + RACK_WALL, rack.ny * RACK_PITCH + RACK_WALL
    box = dict(type=mujoco.mjtGeom.mjGEOM_BOX, rgba=rgba)
    body.add_geom(name=f"{rack.name}_base", size=[lx / 2, ly / 2, RACK_BASE / 2], pos=[0, 0, RACK_BASE / 2], **box)
    zc, hz = (RACK_BASE + RACK_HEIGHT) / 2, (RACK_HEIGHT - RACK_BASE) / 2
    for i in range(rack.nx + 1):
        body.add_geom(size=[RACK_WALL / 2, ly / 2, hz], pos=[-lx / 2 + RACK_WALL / 2 + i * RACK_PITCH, 0, zc], **box)
    for j in range(rack.ny + 1):
        body.add_geom(size=[lx / 2, RACK_WALL / 2, hz], pos=[0, -ly / 2 + RACK_WALL / 2 + j * RACK_PITCH, zc], **box)


def _add_tube(spec: mujoco.MjSpec, name: str, xy, rgba) -> None:
    """Capped sample vial (28 mm x 75 mm). The body origin is the bottom centre."""
    body = spec.worldbody.add_body(name=name, pos=[xy[0], xy[1], RACK_BASE + 0.001])
    body.add_freejoint(name=f"{name}_free")
    cap = 0.012
    body_len = TUBE_LENGTH - cap
    cyl = dict(type=mujoco.mjtGeom.mjGEOM_CYLINDER, friction=[1.5, 0.01, 0.0005], condim=4)
    # The vial stands on a thin box: a cylinder face resting on a box rocks forever in MuJoCo 3.5,
    # the version CaP-X locks.
    foot, lift = 0.0095, 0.001
    body.add_geom(name=f"{name}_foot", type=mujoco.mjtGeom.mjGEOM_BOX, size=[foot, foot, lift], pos=[0, 0, lift],
                  rgba=[0.9, 0.9, 0.95, 0.6], mass=0.001, friction=[1.0, 0.01, 0.0005])
    body.add_geom(name=f"{name}_body", size=[TUBE_RADIUS, (body_len - lift) / 2, 0], pos=[0, 0, (body_len + lift) / 2],
                  rgba=[0.9, 0.9, 0.95, 0.6], mass=TUBE_MASS * 0.85, **cyl)
    body.add_geom(name=f"{name}_cap", size=[TUBE_RADIUS, cap / 2, 0], pos=[0, 0, body_len + cap / 2],
                  rgba=rgba, mass=TUBE_MASS * 0.15, **cyl)


def _yaw_quat(yaw: float) -> list[float]:
    return [np.cos(yaw / 2), 0, 0, np.sin(yaw / 2)]


def build_spec(layout: Layout | None = None) -> mujoco.MjSpec:
    layout = layout or Layout()
    spec = mujoco.MjSpec()
    spec.modelname = "biolab_tube_rack"
    spec.option.integrator = mujoco.mjtIntegrator.mjINT_IMPLICITFAST
    spec.option.timestep = 0.002
    spec.option.cone = mujoco.mjtCone.mjCONE_ELLIPTIC
    spec.option.impratio = 10  # stiffer friction so grasped tubes do not creep
    spec.visual.global_.offwidth, spec.visual.global_.offheight = 1280, 960

    world = spec.worldbody
    world.add_light(pos=[0.2, 0, 1.5], dir=[0, 0, -1], diffuse=[0.45, 0.45, 0.45])
    world.add_light(pos=[-0.5, 0.8, 1.2], dir=[0.4, -0.6, -0.7], diffuse=[0.25, 0.25, 0.25])
    world.add_geom(name="floor", type=mujoco.mjtGeom.mjGEOM_PLANE, size=[2, 2, 0.05], pos=[0, 0, -0.75],
                   rgba=[0.35, 0.37, 0.4, 1])
    world.add_geom(name="table", type=mujoco.mjtGeom.mjGEOM_BOX, size=[0.45, 0.60, 0.02], pos=[0.10, 0, -0.02],
                   rgba=[0.62, 0.6, 0.56, 1])

    for arm in ARMS:
        yam = mujoco.MjSpec.from_file(str(YAM_XML))
        for element in [*yam.lights, *yam.keys]:
            yam.delete(element)
        # The stock gripper tops out near 4 N; give it enough force to hold labware.
        for act in yam.actuators:
            if act.name == "gripper":
                act.gainprm[0] = 1000
                act.biasprm[1] = -1000
                act.biasprm[2] = -40
                act.forcerange = [-40, 40]
        link6 = next(b for b in yam.bodies if b.name == "link_6")
        # Looks along the fingers from the side opposite the pads (approximate, not the real D405 mount).
        # Menagerie's grasp_site sits on the wrist axis; the finger pads are offset 44 mm from it.
        link6.add_site(name="pinch_site", pos=[0, -0.044, 0.1297], quat=[1, 0, 0, -1], size=[0.004, 0, 0],
                       rgba=[0, 0.6, 1, 1], group=4)
        link6.add_camera(name="wrist_cam", pos=[0, 0.085, 0.07], xyaxes=[-1, 0, 0, 0, 0.9, 0.44], fovy=75)
        frame = world.add_frame(pos=ARM_BASE[arm])
        spec.attach(yam, prefix=f"{arm}/", frame=frame)

    _add_rack(spec, layout.source, rgba=[0.15, 0.55, 0.6, 1])
    _add_rack(spec, layout.dest, rgba=[0.6, 0.35, 0.6, 1])
    for i, (name, cell) in enumerate(layout.tubes.items()):
        _add_tube(spec, name, layout.source.cell_xy(*cell), TUBE_COLORS[i % len(TUBE_COLORS)])

    world.add_camera(name="overhead", pos=[0.12, 0, 1.0], xyaxes=[0, -1, 0, 1, 0, 0], fovy=50)
    world.add_camera(name="front", pos=[0.95, 0, 0.45], xyaxes=[0, 1, 0, -0.42, 0, 0.91], fovy=50)
    return spec


def build_model(layout: Layout | None = None) -> mujoco.MjModel:
    return build_spec(layout).compile()
