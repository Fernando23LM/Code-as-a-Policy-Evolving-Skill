"""Functions exposed to code-writing models. The docstrings are all a model sees.

Plain Python, no CaP-X imports, so the same API serves CaP-X (biolab.capx_env)
and the library loop (biolab.evolve).
"""
from __future__ import annotations

from typing import Any

import numpy as np

from .env import TubeRackEnv


class TubeRackApi:
    """Control of the two YAM arms plus ground-truth scene state."""

    def __init__(self, sim: TubeRackEnv) -> None:
        self.sim = sim

    def functions(self) -> dict[str, Any]:
        return {
            "get_task": self.get_task,
            "get_tube_pose": self.get_tube_pose,
            "get_rack": self.get_rack,
            "get_gripper_pose": self.get_gripper_pose,
            "move_to": self.move_to,
            "set_gripper": self.set_gripper,
            "go_home": self.go_home,
        }

    def get_task(self) -> dict:
        """Get the goal of this episode.

        Returns:
            dict with keys:
              "instruction": str, the goal in words.
              "tube": str, name of the vial to move, e.g. "tube_1".
              "dest_cell": (ix, iy) tuple of ints, the target cell of "rack_dest".
        """
        task = self.sim.task
        return {"instruction": task.instruction, "tube": task.tube, "dest_cell": tuple(task.dest_cell)}

    def get_tube_pose(self, tube: str) -> tuple[np.ndarray, np.ndarray]:
        """Get where a vial is. Vials are capped cylinders, 28 mm diameter and 75 mm tall.

        Args:
            tube: vial name, "tube_0" or "tube_1".

        Returns:
            bottom: (3,) XYZ in metres of the centre of the vial's bottom face, world frame.
            top: (3,) XYZ in metres of the centre of the vial's cap.
        """
        state = self.sim.perceive()["tubes"][tube]
        return state["bottom"].copy(), state["top"].copy()

    def get_rack(self, rack: str) -> dict:
        """Get a rack's angle and the positions of its cells.

        Racks are fixed to the table, 35 mm tall, with a 4 x 2 grid of square cells
        (32 mm opening, 37 mm pitch). Cell (ix, iy) has ix in 0..3 along the rack's
        long side and iy in 0..1 along its short side.

        Args:
            rack: "rack_source" (holds the vials at the start) or "rack_dest" (empty).

        Returns:
            dict with keys:
              "yaw": float, rotation of the rack's long side about world Z, radians.
              "cells": dict mapping (ix, iy) to (3,) XYZ in metres of the point where
                a seated vial's bottom centre rests.
        """
        state = self.sim.perceive()["racks"][rack]
        return {"yaw": float(state["yaw"]), "cells": {c: p.copy() for c, p in state["cells"].items()}}

    def get_gripper_pose(self, arm: str) -> dict:
        """Get the current gripper state of one arm.

        Args:
            arm: "left" or "right".

        Returns:
            dict with keys "pos" ((3,) XYZ in metres of the pinch point between the
            finger pads), "yaw" (radians) and "opening" (metres between the pads).
        """
        return self.sim.ee_pose(arm)

    def move_to(self, arm: str, position: np.ndarray, yaw: float = 0.0, tilt: float = 0.0,
                speed: float = 0.15) -> bool:
        """Move the pinch point of an arm's gripper in a straight line to a position.

        World frame: metres, Z up, table top at z = 0. The right arm's base is at
        (-0.20, -0.28, 0) and the left arm's at (-0.20, 0.28, 0), both facing +X.
        Only the right arm can reach the racks.

        Args:
            arm: "left" or "right".
            position: (3,) XYZ target of the pinch point in metres.
            yaw: rotation of the gripper about world Z in radians. At yaw = 0 the
              fingers close along world Y. To close the fingers across a rack's
              short side, use the rack's yaw.
            tilt: 0 points the gripper straight down; positive leans it forward.
              Straight down is always reachable over the racks below z = 0.15.
              Between 0.15 and 0.19 it depends on the position, and above that
              it is not reachable, so check the return value.
            speed: metres per second. Use about 0.05 to 0.08 for the last
              centimetres of a grasp or an insertion.

        Returns:
            True if the target was reached within 1 mm. False if the target is
            unreachable, in which case the arm DOES NOT MOVE AT ALL, or if the
            arm was blocked on the way, for example by a vial resting on a rack
            wall. Continuing after a False usually drags or drops what is held.
        """
        return bool(self.sim.move_to(arm, np.asarray(position, dtype=float), yaw, tilt, speed))

    def set_gripper(self, arm: str, opening: float) -> None:
        """Open or close a gripper and wait for it to settle.

        The fingers do not fit between vials in touching cells. The two vials
        never start in touching cells, so at the source rack the cells around
        the vial to grasp are free.

        Args:
            arm: "left" or "right".
            opening: commanded distance between the finger pads in metres, from
              0.0 to 0.082. The fingers are position-controlled springs: they
              stop on whatever they hold and squeeze with a force proportional
              to how far the command is below the object (about 0.5 N per mm,
              40 N at most). Command 0.0 for a firm grip. A held 28 mm vial
              reads as an opening of about 0.025, so commanding 0.025 applies
              almost no force.
        """
        self.sim.set_gripper(arm, float(opening))

    def go_home(self, arm: str) -> None:
        """Move an arm back to its resting pose, clear of the racks.

        Args:
            arm: "left" or "right".
        """
        self.sim.home(arm)


REFERENCE_POLICY = """
task = get_task()
bottom, top = get_tube_pose(task["tube"])
source, dest = get_rack("rack_source"), get_rack("rack_dest")

travel_z = 0.152                      # carried vial clears the standing ones
grasp = top.copy()
grasp[2] -= 0.018                     # pinch just below the cap
place = dest["cells"][task["dest_cell"]].copy()
place[2] += grasp[2] - bottom[2] + 0.004   # let go 4 mm above the rack base

set_gripper("right", 0.05)
ok = move_to("right", [grasp[0], grasp[1], travel_z], source["yaw"])
ok = ok and move_to("right", grasp, source["yaw"], speed=0.08)
set_gripper("right", 0.0)
ok = ok and move_to("right", [grasp[0], grasp[1], travel_z], source["yaw"], speed=0.08)
ok = ok and move_to("right", [place[0], place[1], travel_z], dest["yaw"])
ok = ok and move_to("right", place, dest["yaw"], speed=0.05)
set_gripper("right", 0.05)
ok = ok and move_to("right", [place[0], place[1], travel_z], dest["yaw"], speed=0.08)
go_home("right")
print("all moves reached:", ok)
"""
