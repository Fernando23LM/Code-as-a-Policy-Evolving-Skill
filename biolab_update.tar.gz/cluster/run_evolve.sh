#!/bin/bash
#SBATCH -A shey
#SBATCH -q standby
#SBATCH -p a30,a10,a100-40gb,a100-80gb
#SBATCH --gres=gpu:1
#SBATCH -n 4
#SBATCH --mem=16G
#SBATCH -t 03:00:00
#SBATCH -o evolve_%j.log
#
# Library loop: practice rounds with a persistent skill library, then a held-out test.
# One model call per round. Re-submitting with the same RUN resumes it.
#
#   RUN=luna_loop     MODEL=gpt-6-luna sbatch cluster/run_evolve.sh
#   RUN=luna_restarts MODEL=gpt-6-luna EXTRA="--restarts --no-early-stop" sbatch cluster/run_evolve.sh
#   RUN=luna_task2    MODEL=gpt-6-luna EXTRA="--inherit $RCAC_SCRATCH/biolab_runs/luna_loop/library" sbatch cluster/run_evolve.sh
#   RUN=reference     EXTRA="--reference" sbatch cluster/run_evolve.sh      # no model, no cost
set -uo pipefail

RUN=${RUN:?set RUN to a name for this run}
MODEL=${MODEL:-}
ROUNDS=${ROUNDS:-8}
BASE_URL=${BASE_URL:-https://api.experientiallabs.ai/v1/}
KEY_FILE=${KEY_FILE:-$RCAC_SCRATCH/capx/.expkey}
EXTRA=${EXTRA:-}

# Reuses CaP-X's environment (it has MuJoCo and this project installed). No rendering, so no EGL.
PY=$RCAC_SCRATCH/capx/cap-x/.venv/bin/python
OUT=$RCAC_SCRATCH/biolab_runs/$RUN

# shellcheck disable=SC2086
$PY -u -m biolab.evolve --run-dir "$OUT" --model "$MODEL" --base-url "$BASE_URL" --key-file "$KEY_FILE" \
    --rounds "$ROUNDS" $EXTRA
echo "exit code: $?  run folder: $OUT"
